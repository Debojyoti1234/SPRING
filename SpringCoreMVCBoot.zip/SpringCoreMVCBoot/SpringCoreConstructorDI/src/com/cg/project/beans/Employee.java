package com.cg.project.beans;

public class Employee {
private String firstName,lastName,basicSalary;
private String employeeId;
private Address address;

public Employee(String firstName, String lastName, String basicSalary, String employeeId, Address address) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.basicSalary = basicSalary;
	this.employeeId = employeeId;
	this.address = address;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getBasicSalary() {
	return basicSalary;
}
public void setBasicSalary(String basicSalary) {
	this.basicSalary = basicSalary;
}
public String getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(String employeeId) {
	this.employeeId = employeeId;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
@Override
public String toString() {
	return "Employee [firstName=" + firstName + ", lastName=" + lastName + ", basicSalary=" + basicSalary
			+ ", employeeId=" + employeeId + ", address=" + address + "]";
}


}
